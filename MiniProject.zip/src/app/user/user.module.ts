import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RegisterComponent } from './register/register.component';
//import { AppRoutingModule ,routingComponents } from '../app-routing.module';
import {ReactiveFormsModule} from '@angular/forms';
import { LoginNewComponent } from './login-new/login-new.component';
import { UpdateUserComponent } from './update-user/update-user.component';

@NgModule({
  declarations: [RegisterComponent, LoginNewComponent, UpdateUserComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  exports:[LoginNewComponent,RegisterComponent,UpdateUserComponent]
})
export class UserModule { }

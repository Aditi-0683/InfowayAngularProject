import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl, FormControlName, Validators, FormControlDirective} from '@angular/forms';
import { UserService} from '../../user.service';
// for toastr
import {NotificationService} from '../../notification.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-login-new',
  templateUrl: './login-new.component.html',
  styleUrls: ['./login-new.component.css']
})


export class LoginNewComponent implements OnInit {
  loginForm:FormGroup
  
  login()
  { 
    if(this.loginForm.value.uname == "admin" && this.loginForm.value.pass=="admin")
    {
        this.notification.showSuccess("Admin successfully login","Success");
        this.router.navigateByUrl("admin");
        
    }
    else{
      this.notification.showError("You are not admin","Error");
    }
  }
  
  constructor(private userService:UserService,private router:Router,private notification:NotificationService) { }

  ngOnInit(): void {
    this.loginForm = new FormGroup({
      uname:new FormControl(""),
      pass:new FormControl(""),
    })
  }

}

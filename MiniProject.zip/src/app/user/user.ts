export interface User
{
    first_name:string;
    last_name:string;
    mob:number;
    email:string;
    address:string;
    password:string;
    confirm_pass:string;
    

}
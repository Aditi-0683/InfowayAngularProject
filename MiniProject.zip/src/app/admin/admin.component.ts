import { Component, OnInit } from '@angular/core';
// importing service
import { ProductService } from '../product.service';
import { UserService } from '../user.service';
// for toastr
import {NotificationService} from '../notification.service';



@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  product:any=[];
  user:any=[];

  constructor(private productService:ProductService,private userService:UserService,private notification:NotificationService) { }

  getProductData()
  {
    // getting data using service obj, data comes in res and store in student array
    this.productService.getData().subscribe((res)=>{
      this.product = res
    })
  }

  deleteProduct(id)
  {
    this.productService.deleteData(id).subscribe((res)=>{
      this.notification.showSuccess("Product deleted successfully ","Success");
      this.getProductData(); // for refreshing the product list
      
    })
  }

  getUserData()
  {
    this.userService.getData().subscribe((res1)=>{
    this.user = res1
    })
  }

  deleteUser(id)
  {
    this.userService.deleteData(id).subscribe((res)=>{
      this.notification.showSuccess("User deleted successfully ","Success");
      this.getUserData(); // for refreshing the user list
      
    })
  }

  ngOnInit(): void {
    this.getProductData();
    this.getUserData();
  }

}
